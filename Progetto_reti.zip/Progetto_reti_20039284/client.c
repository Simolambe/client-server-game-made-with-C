#include <stdio.h>      
#include <sys/types.h>
#include <sys/socket.h>   
#include <netdb.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <stdbool.h>
#include <ctype.h>

int main(int argc, char *argv[]) {

    bool err;
    char *str1;
    char tentativi[3];
    char * benvenuto;
    int guessed = 0;
    int num_tentativi;
    char risposta[6];
    char parola[6] ="";
    int simpleSocket = 0;
    int simplePort = 0;
    int returnStatus = 0;
    char buffer[256] = "";
    char servermessage[256] = "";
    struct sockaddr_in simpleServer;

    /* controllo sul numero di argomenti */
    if (3 != argc) {

        fprintf(stderr, "Numero di argomenti errato\n");
        exit(1);

    }

    /* creo una streaming socket      */
    simpleSocket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);

    if (simpleSocket == -1) {

        fprintf(stderr, "Impossibile creare la socket!\n");
        exit(1);

    }
    else {
	    fprintf(stderr, "Socket creata!\n");
    }

    /* ottengo il numero di porta da linea di comando  */
    simplePort = atoi(argv[2]);

    /* setup degli indirizzi */
    /* use the IP address sent as an argument for the server address  */
    //bzero(&simpleServer, sizeof(simpleServer)); 
    memset(&simpleServer, '\0', sizeof(simpleServer));
    simpleServer.sin_family = AF_INET;
    //inet_addr(argv[2], &simpleServer.sin_addr.s_addr);
    simpleServer.sin_addr.s_addr=inet_addr(argv[1]);
    simpleServer.sin_port = htons(simplePort);

    /*  connect al giusto indirizzo e numero di porta  */
    returnStatus = connect(simpleSocket, (struct sockaddr *)&simpleServer, sizeof(simpleServer));

    if (returnStatus == 0) {
	    fprintf(stderr, "La connessione ha avuto successo!\n");
    }
    else {
        fprintf(stderr, "Impossibile connettersi all'indirizzo!\n");
	close(simpleSocket);
	exit(1);
    }
    
    /* QUI PARTE L'ESECUZIONE DEL PROGRAMMA */
     
      

    /* ricevo il benvenuto dal server e lo stampo */
    read(simpleSocket, servermessage, sizeof(servermessage));
    str1 = strtok(servermessage," ");
    strcpy(tentativi,strtok(NULL," "));
    num_tentativi = atoi(tentativi);
    while(str1 != NULL){
        if(strcmp("OK",str1)==0){
            str1 = strtok(NULL," ");
        }
        printf("%s ",str1);
        str1 = strtok(NULL," ");
    }
       
    /* spiegazione regole */ 
    printf("\n Se le due parole sono uguali il gioco terminera', se e' stata inserita una lettera nella posizione giusta verra' restituito il carattere *, mentre se e' stata inserita una lettera giusta ma nella poszione sbagliata verra' restituito il carttere +, un carattere totalmente errato restituisce - \n\n");    
       
       
    /* pulisco il buffer */
    memset(buffer,0, sizeof(buffer));
    memset(servermessage,0, sizeof(servermessage));


    /* chiedo all'utente di inserire un comando e gestisco eventuali errori */
    while(num_tentativi > 0 && !err){
        
    do{

        printf("Digita word se vuoi provare a indovinare la parola o quit se vuoi andartene, hai ancora %d tentativi per indovinare\n",num_tentativi);
	scanf("%s",risposta);
	
	/* non faccio differenze tra maiuscole e minuscole */
             for(int j=0; j<strlen(risposta);j++){
                 risposta[j] = tolower(risposta[j]);
             }
	if(strcmp(risposta,"word")!=0 && strcmp(risposta,"quit")!=0){
	    printf("hai inserito un comando non valido \n");
	}

     }  while(strcmp(risposta,"word")!=0 && strcmp(risposta,"quit")!=0);

 
         /* se il comando e' quit */
         if(strcmp(risposta,"quit")==0){    
 	
             char buffer[] ="QUIT\n";                      
             write(simpleSocket,buffer,strlen(buffer));
             memset(buffer,0, sizeof(buffer));             
             read(simpleSocket, servermessage, sizeof(servermessage));
             str1 = NULL;
             str1 = strtok(servermessage," ");
             while(str1 != NULL){
                 if(strcmp("QUIT",str1)==0){
                 str1 = strtok(NULL," ");
                 }
              printf("%s ",str1);
              str1 = strtok(NULL," ");
             }           
             memset(servermessage,0, sizeof(servermessage));            
	     break;
         }
 
         /* se il comando e' word */
         else if(strcmp(risposta,"word")==0){    
 	
             char buffer[] ="WORD ";                      
             printf("scrivi la parola da inserire, ricorda che deve essere di cinque lettere \n");
             scanf("%s",parola);
                                                                     
             strcat(buffer,parola); 
             strcat(buffer,"\n");      
             write(simpleSocket,buffer,strlen(buffer));
             memset(buffer,0, sizeof(buffer));                             
             read(simpleSocket, servermessage, sizeof(servermessage));
             
             /* se ho indovinato la parola */
             if(strcmp("OK PERFECT\n",servermessage) == 0){
             printf("Hai indovinato la parola, chiusura connessione... \n");
             break;
             }
             
             str1 = NULL;
             str1 = strtok(servermessage," ");
                                       
             while(str1 != NULL){
                 /* se non ho indovinato la parola */
                 if(strcmp("OK",str1)==0){
                 str1 = strtok(NULL," ");
                 printf("Non hai indovinato, questo era il tentativo numero ");
                 }
                 /* se ho finito i tentativi */
                 else if(strcmp("END",str1)==0){
                     printf("Hai esaurito i tentativi, chiusura connessione...\n");  
                     break;                  
                 }
                 /* se si verifica un errore chiudo la connessione */
                 else if(strcmp("ERR",str1)==0){
                     str1 = strtok(NULL," ");
                     fprintf(stderr,"Si e' verificato il seguente errore : ");
                     err = true;
                 }
                     
              printf("%s ",str1);
              str1 = strtok(NULL," ");
             }        

	     num_tentativi--;
             memset(servermessage,0, sizeof(servermessage));            
         }

 }
 
    /* chiudo la connessione */
    close(simpleSocket);
    printf("connessione col server chiusa \n");
    return 0;

}

