#include <stdio.h>      
#include <sys/types.h>
#include <sys/socket.h>   
#include <netdb.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h> 
#include <time.h>
#include <stdbool.h>
#define num_max_parole 200


   /* funzione che confronta la parola dell'utente e quella da indovinare */
   char* wordle(char answer[], char guess[]){

        char clue[6] = {'-','-','-','-','-','\0'};

            for(int i=0;i<5;i++){
                if(guess[i] == answer[i]){
                    clue[i] = '*';
                }
            }
            
            for(int i=0;i<5;i++){
                if(clue[i] == '-'){
                    for(int j=0; j<5; j++){
                        if(guess[i] == answer[j] && guess[i] != answer[i]){
                            clue[i] = '+';
                        }
                    }            
                }
           }
           
        char *clue_ptr = clue;   
        return clue_ptr;          
    }





int main(int argc, char *argv[]) {

    char tentativi_fatti_str[3] = "";
    char *pointer;
    char *str1;
    char str2[6];
    FILE* ptr;
    int tentativi;
    int tentativi_fatti = 0;
    char risultato[6];
    char parole[num_max_parole][6];
    char target[6]; /* parola da indovinare */
    char buffer[256] = "";
    char clientmessage[256] ="";
    int simpleSocket = 0;
    int simplePort = 0;
    int returnStatus = 0;
    char max_tentativi[] = "6";
    char benvenuto[] = " Benvenuto devi indovinare la parola del giorno \n";
    struct sockaddr_in simpleServer;
    
    /*apro il file contenente le parole da indovinare */
    ptr = fopen("parole.txt","r");
    
    if (ptr == NULL){
    	fprintf(stderr,"impossibile aprire il file \n");
    } 
    
    /* salvo le parole tra le quali scegliero' quella del giorno */
    for(int i = 0; i < num_max_parole; i++){    
        
        fscanf(ptr, "%s", parole[i]);
        
        }
    
    fclose(ptr);

    /* controllo il numero di elementi inseriti da linea di comando */
    if (2 != argc && 3 != argc) {

        fprintf(stderr, "Numero di argomenti errato");
        exit(1);

    }
    
    /* se l'utente inserisce il numero di tentativi lo recupero da linea di comando*/
    if (argc == 3){
  
  	if (atoi(argv[2]) > 10 || atoi(argv[2]) < 6){
  	
  	    fprintf(stderr, "Numero tentativi inserito non compreso tra 6 e 10");
            exit(1);
  	    
  	}
    	
    	strcpy(max_tentativi,argv[2]);
    	
    }
    
    tentativi = atoi(max_tentativi);
    
    /* ottengo il numero di porta da linea di comando */
    simplePort = atoi(argv[1]);

    /* creo la socket */
    simpleSocket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);

    if (simpleSocket == -1) {

        fprintf(stderr, "Impossibile creare la socket!\n");
        exit(1);

    }
    else {
        fprintf(stderr, "Socket creata con successo!\n");
    }



    /* setup degli indirizzi */
    /* uso INADDR_ANY per il bind di tutti i local address  */
    memset(&simpleServer, '\0', sizeof(simpleServer)); 
    simpleServer.sin_family = AF_INET;
    simpleServer.sin_addr.s_addr = htonl(INADDR_ANY);
    simpleServer.sin_port = htons(simplePort);

    /*  bind dell'indirizzo e della porta col nostro socket  */
    returnStatus = bind(simpleSocket,(struct sockaddr *)&simpleServer,sizeof(simpleServer));

    if (returnStatus == 0) {
	    fprintf(stderr, "Bind completato!\n");
    }
    else {
        fprintf(stderr, "Impossibile eseguire il bind!\n");
	close(simpleSocket);
	exit(1);
    }

    /* mi metto in ascolto per eventuali connessioni   */
    returnStatus = listen(simpleSocket, 5);

    /* controllo sull'ascolto */
    if (returnStatus == -1) {
        fprintf(stderr, "Impossibile ascoltare la socket!\n");
	close(simpleSocket);
        exit(1);
    }


	while(1){


        struct sockaddr_in clientName = { 0 };
	int simpleChildSocket = 0;
	int clientNameLength = sizeof(clientName);

	/* attendo */

        simpleChildSocket = accept(simpleSocket,(struct sockaddr *)&clientName, &clientNameLength);

	if (simpleChildSocket == -1) {

            fprintf(stderr, "Impossibile stabilire una connessione!\n");
	    close(simpleSocket);
	    exit(1);

	}
	 
/* QUI PARTE L'ESECUZIONE DEL PROGRAMMA */	

        /* reimposto il numero di tentativi */
        tentativi = atoi(max_tentativi);
 	tentativi_fatti = 0; 
	/* imposto la parola da indovinare */ 
        srand(time(NULL));
        pointer = parole[rand()%(num_max_parole + 1)];
        strcpy(target,pointer);
/*      printf("la parola da indovinare e' = %s\n",target); */
                        
	/* scrivo il messaggio di benvenuto al client */	
	strcat(buffer,"OK ");
	strcat(buffer,max_tentativi);
	strcat(buffer,benvenuto);
	
	write(simpleChildSocket, buffer, strlen(buffer));
	
	/* pulisco il buffer */
	memset(buffer,0, sizeof(buffer));
	memset(clientmessage,0, sizeof(clientmessage));
	
	/* inizio il gioco */	
	while(tentativi > 0){
	
	    strcpy(str2,"");
	    memset(clientmessage,0, sizeof(clientmessage));
	    
	    /* ricevo il comando dal client */ 	
	    read(simpleChildSocket,clientmessage,sizeof(clientmessage));
	    str1 = strtok(clientmessage," "); 
            
            if(strcmp("WORD",str1)==0){
            
 	        strcpy(str2,strtok(NULL,"\n"));
 	    
 	        /* controllo la lunghezza della parola, nel caso invio un errore */
 	        if(strlen(str2) != 5){
 	        
 	            char buffer[] = "ERR la parola deve essere lunga 5 caratteri \n";
	            write(simpleChildSocket, buffer, strlen(buffer));
	            memset(buffer,0, sizeof(buffer)); 	        
	            break; 
 	        
 	        } 	    
 	    }
 	    	   
 	    /* Se il comando e' quit */
	    if(strcmp("QUIT\n",str1)==0){
	    
	        char buffer[] = "QUIT Vai via cosi presto? La parola era ";
	        strcat(buffer,target);
	        strcat(buffer,"\n");
	        write(simpleChildSocket, buffer, strlen(buffer));
	        memset(buffer,0, sizeof(buffer)); 
	        break;
	    
	    }
	
	   /* Se il comando e' word */ 
	   else if (strcmp("WORD",str1)==0){
	   
	       /* nel caso in cui il client fosse all'ultimo tentativo */
	       if(tentativi == 1 && strcmp(target,str2) !=0){
	       
	        char buffer[] = "END ";
	        strcat(buffer,max_tentativi);
	        strcat(buffer," ");
	        strcat(buffer,target);
	        write(simpleChildSocket, buffer, strlen(buffer));
	        memset(buffer,0, sizeof(buffer));    
	        break;
	        
	       }
	   
	       /* nel caso in cui la parola fosse indovinata */
	       if (strcmp(target,str2) ==0){
	       
	            char buffer[] = "OK PERFECT\n";
	            write(simpleChildSocket, buffer, strlen(buffer));
	            memset(buffer,0, sizeof(buffer)); 	        
	            break;
	            
	       }
	           
	       /* caso in cui la parola non viene indovinata */
	       else{
	       
	            strcpy(risultato,wordle(target,str2));		     
	            tentativi_fatti ++;
	            sprintf(tentativi_fatti_str,"%d",tentativi_fatti);
	            char buffer[] = "OK ";
	            strcat(buffer,tentativi_fatti_str);
	            strcat(buffer," ");
	            strcat(buffer,risultato);
	            strcat(buffer,"\n");
	            write(simpleChildSocket, buffer, strlen(buffer));
	            memset(buffer,0, sizeof(buffer)); 	        
	            tentativi--;      
	       }
	  }     
	   /* errore in caso di comando errato */
	   else{
	   
	       char buffer[] = "ERR inserisci un comando valido \n";
	       write(simpleChildSocket, buffer, strlen(buffer));
	       memset(buffer,0, sizeof(buffer)); 	        
	       break;  	           	       	       
	   
	   }
	   	
	}
	        
        /* chiudo la connessione */
        close(simpleChildSocket);
        printf("connessione chiusa col client \n");

       }

    close(simpleSocket);
    return 0;

}

